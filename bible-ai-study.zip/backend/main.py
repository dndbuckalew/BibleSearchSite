# backend/main.py
import os
from typing import Optional, List
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests
import openai

# Load env vars (ensure you set OPENAI_API_KEY in environment)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError("Set OPENAI_API_KEY environment variable before running.")
openai.api_key = OPENAI_API_KEY

# Bible API base (public/simple). You can replace with another provider if you prefer.
BIBLE_API_BASE = "https://bible-api.com"  # used like: /john%203:16

app = FastAPI(title="Bible AI Study Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- Models ----------
class QueryRequest(BaseModel):
    question: str
    translation: Optional[str] = "kjv"             # "kjv", "esv" etc. (bible-api supports some)
    want_commentary: Optional[bool] = False
    persona: Optional[str] = None                  # e.g., "seeker", "believer", "scholar"

class VerseItem(BaseModel):
    reference: str
    text: str

class QueryResponse(BaseModel):
    verses: List[VerseItem]
    summary: str
    commentary: Optional[str] = None

# ---------- Helpers ----------
def fetch_verses_for_topic(topic: str, translation: str = "kjv", max_results=6):
    """
    Simple heuristic: use OpenAI to generate verse references for the topic,
    then fetch those verses from the Bible API.
    """
    # 1) Ask OpenAI to suggest relevant verse references (short list)
    prompt = (
        "You are a biblical reference assistant. Given a topic, list up to "
        f"{max_results} Bible verse references (short form like 'John 3:16' or 'Ephesians 4:32') "
        "that directly address the topic. Return only the references separated by commas.\n\n"
        f"Topic: {topic}\nReferences:"
    )
    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini",   # replace with available model in your account
        messages=[{"role": "user", "content": prompt}],
        max_tokens=200,
        temperature=0.0,
    )
    text = resp["choices"][0]["message"]["content"].strip()
    # parse comma/line separated references
    refs = []
    for chunk in text.replace("\n", ",").split(","):
        r = chunk.strip()
        if r:
            refs.append(r)
    # limit
    refs = refs[:max_results]

    # 2) Fetch verse text for each reference
    verses = []
    for r in refs:
        # bible-api expects the reference as path, e.g. /john%203:16
        try:
            url = f"{BIBLE_API_BASE}/{requests.utils.quote(r)}"
            q = {"translation": translation} if translation else {}
            res = requests.get(url, params=q, timeout=10)
            if res.status_code == 200:
                data = res.json()
                # bible-api returns 'verses' or 'text' depending on endpoint; handle common keys
                if "text" in data and isinstance(data["text"], str):
                    text_body = data["text"].strip()
                elif "verses" in data and isinstance(data["verses"], list):
                    text_body = " ".join(v.get("text", "") for v in data["verses"]).strip()
                else:
                    text_body = data.get("reference", r)
                verses.append({"reference": data.get("reference", r), "text": text_body})
            else:
                verses.append({"reference": r, "text": f"[Could not fetch verse: {res.status_code}]"})
        except Exception as e:
            verses.append({"reference": r, "text": f"[Error fetching verse: {str(e)}]"})
    return verses

def summarize_and_contextualize(question: str, verses: List[dict], persona: Optional[str], want_commentary: bool):
    # Build prompt to ask OpenAI to summarize and optionally add commentary
    verse_text_bundle = "\n\n".join(f"{v['reference']}: {v['text']}" for v in verses)
    persona_instructions = ""
    if persona:
        if persona.lower() == "seeker":
            persona_instructions = "Write gently and use simple, welcoming language for someone exploring faith."
        elif persona.lower() == "believer":
            persona_instructions = "Focus on application and actionable steps to apply these verses."
        elif persona.lower() == "scholar":
            persona_instructions = "Include historical or language notes and cross references; be more technical."
        else:
            persona_instructions = f"Tone adapted for: {persona}."

    base_prompt = (
        "You are a careful Bible-study assistant. The user asked:\n\n"
        f"QUESTION: {question}\n\n"
        "Here are candidate verses:\n\n"
        f"{verse_text_bundle}\n\n"
        "Task 1: Provide a concise synthesis (3-6 sentences) of how these verses answer the user's question.\n"
        f"Task 2: If the user asked for commentary, provide a brief paragraph (2-4 sentences) summarizing insights from classical commentators (e.g., Matthew Henry, John Gill) and label it 'Commentary:'.\n\n"
        f"{persona_instructions}\n\n"
        "Return JSON with keys: summary (string) and commentary (string or empty). ONLY RETURN JSON."
    )

    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": base_prompt}],
        max_tokens=400,
        temperature=0.2,
    )
    ai_text = resp["choices"][0]["message"]["content"].strip()
    # Simple approach: expect JSON; try parse
    import json
    try:
        parsed = json.loads(ai_text)
        summary = parsed.get("summary", "")
        commentary = parsed.get("commentary", "")
    except Exception:
        # fallback: split heuristically
        if "Commentary:" in ai_text:
            summary, commentary = ai_text.split("Commentary:", 1)
            summary = summary.strip()
            commentary = commentary.strip()
        else:
            summary = ai_text
            commentary = ""
    return summary, commentary

# ---------- Endpoints ----------
@app.post("/api/query", response_model=QueryResponse)
def handle_query(req: QueryRequest):
    if not req.question or len(req.question.strip()) < 3:
        raise HTTPException(status_code=400, detail="Provide a clear question.")

    # Step 1: find verses
    verses = fetch_verses_for_topic(req.question, translation=req.translation)

    # Step 2: call OpenAI to summarize and optionally include commentary
    summary, commentary = summarize_and_contextualize(req.question, verses, req.persona, req.want_commentary)
    result = {
        "verses": verses,
        "summary": summary,
        "commentary": commentary if req.want_commentary else None,
    }
    return result

@app.get("/health")
def health():
    return {"status": "ok"}
