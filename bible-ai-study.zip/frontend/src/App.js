import React, { useState } from "react";

const API_BASE = process.env.REACT_APP_API_BASE || "http://localhost:8000";

export default function App() {
  const [question, setQuestion] = useState(""); 
  const [translation, setTranslation] = useState("kjv");
  const [wantCommentary, setWantCommentary] = useState(false);
  const [persona, setPersona] = useState("seeker");
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState(null);
  const [error, setError] = useState(null);

  async function submit() {
    setError(null);
    if (!question.trim()) {
      setError("Please enter a question.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          translation,
          want_commentary: wantCommentary,
          persona,
        }),
      });
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || "Server error");
      }
      const data = await res.json();
      setResponse(data);
    } catch (e) {
      console.error(e);
      setError(e.message || "Unknown error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app">
      <div className="header">
        <h2>Bible AI Study</h2>
        <div className="small">Starter prototype</div>
      </div>

      <div style={{ marginTop: 12 }}>
        <label className="small">Ask about a topic or pose a question:</label>
        <textarea value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="e.g., What does the Bible say about forgiveness?" />
        <div className="controls">
          <select value={translation} onChange={(e) => setTranslation(e.target.value)}>
            <option value="kjv">KJV</option>
            <option value="esv">ESV</option>
            <option value="niv">NIV</option>
          </select>
          <label style={{display:"flex", alignItems:"center", gap:8}}>
            <input type="checkbox" checked={wantCommentary} onChange={e => setWantCommentary(e.target.checked)} />
            Show theologian commentary
          </label>

          <div className="personaBtns" style={{marginLeft: "auto"}}>
            <label className="small" style={{marginRight:8}}>Persona:</label>
            <button onClick={() => setPersona("seeker")} style={{marginRight:6, background: persona==="seeker" ? "#2563eb" : undefined, color: persona==="seeker" ? "white": undefined}}>Seeker</button>
            <button onClick={() => setPersona("believer")} style={{marginRight:6, background: persona==="believer" ? "#2563eb" : undefined, color: persona==="believer" ? "white": undefined}}>Believer</button>
            <button onClick={() => setPersona("scholar")} style={{background: persona==="scholar" ? "#2563eb" : undefined, color: persona==="scholar" ? "white": undefined}}>Scholar</button>
          </div>
        </div>

        <div style={{marginTop:12}}>
          <button onClick={submit} disabled={loading}>{loading ? "Thinking..." : "Study"}</button>
        </div>

        {error && <div style={{color:"crimson", marginTop:12}}>{error}</div>}

        {response && (
          <div className="verses">
            <h3>Summary</h3>
            <div className="verse">
              <div style={{fontStyle:"italic"}}>{response.summary}</div>
            </div>

            <h3>Verses</h3>
            {response.verses.map(v => (
              <div key={v.reference} className="verse">
                <strong>{v.reference}</strong>
                <div style={{marginTop:6}}>{v.text}</div>
              </div>
            ))}

            {response.commentary && (
              <>
                <h3>Theologian Commentary</h3>
                <div className="verse">{response.commentary}</div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
