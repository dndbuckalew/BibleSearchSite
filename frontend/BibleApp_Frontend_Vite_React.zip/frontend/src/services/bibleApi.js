const API_BASE = "http://127.0.0.1:8000/api";

export async function queryBible(params) {
  const response = await fetch(`${API_BASE}/query`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    throw new Error("API error");
  }

  return await response.json();
}