import React, { useState } from "react";
import { AppProvider } from "./context/AppContext.jsx";
import MainLayout from "./layout/MainLayout.jsx";
import HomePage from "./pages/HomePage.jsx";
import ResultsPage from "./pages/ResultsPage.jsx";
import VerseDetailPage from "./pages/VerseDetailPage.jsx";
import SettingsPage from "./pages/SettingsPage.jsx";
import { useBibleQuery } from "./hooks/useBibleQuery.js";

function AppInner() {
  const [screen, setScreen] = useState("home");
  const [selectedVerse, setSelectedVerse] = useState(null);
  const { loading, verses, error, runQuery } = useBibleQuery();

  function handleSearch(params) {
    runQuery(params);
    setScreen("results");
  }

  function handleVerseSelect(verse) {
    setSelectedVerse(verse);
    setScreen("details");
  }

  function goHome() {
    setScreen("home");
  }

  return (
    <MainLayout currentScreen={screen} onNavigate={setScreen}>
      {screen === "home" && <HomePage onSearch={handleSearch} />}
      {screen === "results" && (
        <ResultsPage
          verses={verses}
          loading={loading}
          error={error}
          onSelectVerse={handleVerseSelect}
          onBack={goHome}
        />
      )}
      {screen === "details" && (
        <VerseDetailPage
          verse={selectedVerse}
          onBack={() => setScreen("results")}
        />
      )}
      {screen === "settings" && <SettingsPage />}
    </MainLayout>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}